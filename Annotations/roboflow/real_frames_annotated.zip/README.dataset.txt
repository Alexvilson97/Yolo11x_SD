# car > 2024-11-07 4:00pm
https://universe.roboflow.com/labeling-ujkwf/car-bprvm

Provided by a Roboflow user
License: CC BY 4.0

